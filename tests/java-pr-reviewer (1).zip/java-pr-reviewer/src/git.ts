import * as vscode from 'vscode';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export interface ChangedFile {
  /** Absolute path on disk. */
  absPath: string;
  /** Repo-relative path (posix style, as git reports). */
  relPath: string;
  /** Unified diff hunks for this file, base..working. */
  diff: string;
  /** Full current file content (working tree). Used to give the model context. */
  content: string;
  /** Map of new-file line number -> true, for lines that were added/modified. */
  changedLines: Set<number>;
}

async function run(cwd: string, cmd: string): Promise<string> {
  const { stdout } = await execAsync(cmd, { cwd, maxBuffer: 50 * 1024 * 1024 });
  return stdout;
}

/** Find the git repo root for a given folder. */
export async function getRepoRoot(folder: string): Promise<string | undefined> {
  try {
    const out = await run(folder, 'git rev-parse --show-toplevel');
    return out.trim();
  } catch {
    return undefined;
  }
}

/**
 * Resolve the ref to diff against. Priority:
 *  1. explicit config baseRef
 *  2. merge-base with the upstream tracking branch
 *  3. merge-base with origin/HEAD (default branch)
 *  4. HEAD (so we only see uncommitted work)
 */
export async function resolveBaseRef(repoRoot: string, configured: string): Promise<string> {
  if (configured && configured.trim()) {
    return configured.trim();
  }
  // Try upstream tracking branch.
  try {
    const upstream = (await run(repoRoot, 'git rev-parse --abbrev-ref --symbolic-full-name @{u}')).trim();
    if (upstream) {
      const mb = (await run(repoRoot, `git merge-base HEAD ${upstream}`)).trim();
      if (mb) return mb;
    }
  } catch { /* no upstream */ }

  // Try origin default branch.
  try {
    const head = (await run(repoRoot, 'git rev-parse --abbrev-ref origin/HEAD')).trim(); // e.g. origin/main
    if (head) {
      const mb = (await run(repoRoot, `git merge-base HEAD ${head}`)).trim();
      if (mb) return mb;
    }
  } catch { /* ignore */ }

  return 'HEAD';
}

/** Parse a unified diff hunk header to know which new-file lines changed. */
function parseChangedLines(diff: string): Set<number> {
  const changed = new Set<number>();
  const lines = diff.split('\n');
  let newLine = 0;
  for (const line of lines) {
    const m = /^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@/.exec(line);
    if (m) {
      newLine = parseInt(m[1], 10);
      continue;
    }
    if (line.startsWith('+') && !line.startsWith('+++')) {
      changed.add(newLine);
      newLine++;
    } else if (line.startsWith('-') && !line.startsWith('---')) {
      // deletion: no new-file line consumed
    } else if (!line.startsWith('\\')) {
      newLine++;
    }
  }
  return changed;
}

interface GetChangesOptions {
  repoRoot: string;
  baseRef: string;
  stagedOnly: boolean;
  includeUntracked: boolean;
  /** Optional filter to a single absolute file path. */
  onlyPath?: string;
}

/** Collect changed Java files with their diffs. */
export async function getChangedCSharpFiles(opts: GetChangesOptions): Promise<ChangedFile[]> {
  const { repoRoot, baseRef, stagedOnly, includeUntracked, onlyPath } = opts;

  // List changed files (names). --diff-filter excludes deleted files (d).
  let nameCmd: string;
  if (stagedOnly) {
    nameCmd = 'git diff --cached --name-only --diff-filter=ACMR';
  } else {
    nameCmd = `git diff --name-only --diff-filter=ACMR ${baseRef}`;
  }
  const namesRaw = await run(repoRoot, nameCmd);
  let names = namesRaw.split('\n').map(s => s.trim()).filter(Boolean);

  if (includeUntracked && !stagedOnly) {
    const untracked = (await run(repoRoot, 'git ls-files --others --exclude-standard'))
      .split('\n').map(s => s.trim()).filter(Boolean);
    names = Array.from(new Set([...names, ...untracked]));
  }

  // Only .java files.
  names = names.filter(n => n.toLowerCase().endsWith('.java'));

  const path = require('path') as typeof import('path');
  const fs = require('fs') as typeof import('fs');

  const results: ChangedFile[] = [];
  for (const rel of names) {
    const abs = path.join(repoRoot, rel);
    if (onlyPath && path.resolve(abs) !== path.resolve(onlyPath)) continue;
    if (!fs.existsSync(abs)) continue;

    let diff = '';
    try {
      if (stagedOnly) {
        diff = await run(repoRoot, `git diff --cached -- "${rel}"`);
      } else {
        // Diff base..working tree. For untracked files, synthesize an all-added diff.
        diff = await run(repoRoot, `git diff ${baseRef} -- "${rel}"`);
        if (!diff.trim()) {
          diff = await run(repoRoot, `git diff --no-index /dev/null "${rel}"`).catch(() => '');
        }
      }
    } catch { /* leave diff empty */ }

    if (!diff.trim()) continue;

    const content = fs.readFileSync(abs, 'utf8');
    results.push({
      absPath: abs,
      relPath: rel,
      diff,
      content,
      changedLines: parseChangedLines(diff)
    });
  }
  return results;
}
