# Java Pre-PR Reviewer

A VS Code extension that reviews **only your changed Java/JVM code** before you raise a pull request,
using **GitHub Copilot's models** through VS Code's Language Model API. Findings appear inline in the
Problems panel with squiggles and quick-fix "copy suggestion" actions.

## Why an extension (not a standalone plugin)?
A VS Code **extension** is the right vehicle: it's the only way to (a) call the built-in Copilot
models via `vscode.lm`, (b) surface results as native diagnostics, and (c) hook the SCM/editor
toolbars. There is no lighter "plugin" layer in VS Code that grants Language Model access.

## How it works
1. Resolves the base ref (upstream tracking branch → `origin/HEAD` → `HEAD`) and computes the diff.
2. Collects changed `.cs` files and the exact added/modified line numbers.
3. Sends each file's diff + full context to a Copilot model with a strict **Java/JVM review prompt**
   that returns JSON.
4. Renders findings as diagnostics (error/warning/info) with categories: async, resource,
   nullability, security, performance, concurrency, design, style, test, docs.

## Requirements
- VS Code 1.90+
- **GitHub Copilot** and **GitHub Copilot Chat** extensions installed and signed in
  (the model access and your org's model entitlements come from Copilot).

## Build & run
```bash
npm install
npm run compile          # or: npm run watch
# Press F5 in VS Code to launch the Extension Development Host
```

## Package as .vsix (for internal distribution)
```bash
npm install -g @vscode/vsce
vsce package
# produces java-pr-reviewer-0.1.0.vsix -> share via your internal marketplace / manual install
```

## Commands
| Command | What it does |
|---|---|
| `Java Reviewer: Review Changed Code` | Reviews all changed Java vs the base branch (SCM toolbar ✨) |
| `Java Reviewer: Review Staged Changes Only` | Reviews only `git add`-ed changes |
| `Java Reviewer: Review Changes in Active File` | Reviews the open file's changes (editor toolbar) |
| `Java Reviewer: Select Copilot Model` | Pick gpt-4o / o3-mini / claude-3.5-sonnet etc. |
| `Java Reviewer: Clear Review Results` | Clears diagnostics |

## Settings
- `javaReviewer.model` — preferred model family (default `gpt-4o`).
- `javaReviewer.baseRef` — override the diff base (e.g. `origin/develop`).
- `javaReviewer.includeUntracked` — also review new files.
- `javaReviewer.severityThreshold` — hide findings below this level.
- `javaReviewer.customGuidelines` — append Northern Trust coding standards to the prompt.

## Northern Trust rollout notes
- Distribute the `.vsix` through your internal extension gallery; pin `model` to an
  org-approved family and preload `customGuidelines` via workspace or machine settings policy.
- All code and prompts stay within the developer's Copilot session — no separate API key or
  external endpoint is introduced.
