import * as vscode from 'vscode';
import { getRepoRoot, resolveBaseRef, getChangedCSharpFiles, ChangedFile } from './git';
import { selectModel, reviewFile, FileReview } from './reviewer';
import { ReviewDiagnostics, SuggestionActionProvider } from './diagnostics';

let diagnostics: ReviewDiagnostics;
let output: vscode.OutputChannel;

export function activate(context: vscode.ExtensionContext) {
  diagnostics = new ReviewDiagnostics();
  output = vscode.window.createOutputChannel('C# Pre-PR Reviewer');

  context.subscriptions.push(
    diagnostics,
    output,
    vscode.languages.registerCodeActionsProvider(
      { language: 'csharp' },
      new SuggestionActionProvider(diagnostics),
      { providedCodeActionKinds: [vscode.CodeActionKind.QuickFix] }
    ),
    vscode.commands.registerCommand('csharpReviewer.reviewChanges', () => runReview({ stagedOnly: false })),
    vscode.commands.registerCommand('csharpReviewer.reviewStaged', () => runReview({ stagedOnly: true })),
    vscode.commands.registerCommand('csharpReviewer.reviewActiveFile', () => {
      const uri = vscode.window.activeTextEditor?.document.uri;
      if (!uri || uri.scheme !== 'file') {
        vscode.window.showWarningMessage('Open a C# file to review its changes.');
        return;
      }
      return runReview({ stagedOnly: false, onlyPath: uri.fsPath });
    }),
    vscode.commands.registerCommand('csharpReviewer.clear', () => diagnostics.clear()),
    vscode.commands.registerCommand('csharpReviewer.pickModel', pickModel),
    vscode.commands.registerCommand('csharpReviewer.copySuggestion', async (text: string) => {
      await vscode.env.clipboard.writeText(text);
      vscode.window.showInformationMessage('Suggested fix copied to clipboard.');
    })
  );
}

export function deactivate() {
  diagnostics?.dispose();
}

async function pickModel() {
  const models = await vscode.lm.selectChatModels({ vendor: 'copilot' });
  if (!models.length) {
    vscode.window.showErrorMessage('No Copilot models available. Ensure GitHub Copilot Chat is installed and signed in.');
    return;
  }
  const pick = await vscode.window.showQuickPick(
    models.map(m => ({ label: m.name, description: `${m.family} · ${m.id}`, family: m.family })),
    { title: 'Select Copilot model for C# review' }
  );
  if (pick) {
    await vscode.workspace.getConfiguration('csharpReviewer').update('model', pick.family, vscode.ConfigurationTarget.Workspace);
    vscode.window.showInformationMessage(`C# Reviewer will use: ${pick.family}`);
  }
}

interface RunOptions {
  stagedOnly: boolean;
  onlyPath?: string;
}

async function runReview(opts: RunOptions) {
  const cfg = vscode.workspace.getConfiguration('csharpReviewer');
  const preferredModel = cfg.get<string>('model', 'gpt-4o');
  const configuredBase = cfg.get<string>('baseRef', '');
  const includeUntracked = cfg.get<boolean>('includeUntracked', false);
  const maxDiffBytes = cfg.get<number>('maxDiffBytesPerFile', 60000);
  const threshold = cfg.get<string>('severityThreshold', 'info');
  const customGuidelines = cfg.get<string>('customGuidelines', '');

  const folder = opts.onlyPath
    ? vscode.workspace.getWorkspaceFolder(vscode.Uri.file(opts.onlyPath))?.uri.fsPath
    : vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;

  if (!folder) {
    vscode.window.showErrorMessage('No workspace folder open.');
    return;
  }

  const repoRoot = await getRepoRoot(folder);
  if (!repoRoot) {
    vscode.window.showErrorMessage('This folder is not a git repository.');
    return;
  }

  const model = await selectModel(preferredModel);
  if (!model) {
    vscode.window.showErrorMessage('No Copilot model available. Install & sign in to GitHub Copilot Chat.');
    return;
  }

  await vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title: 'C# Pre-PR Review', cancellable: true },
    async (progress, token) => {
      progress.report({ message: 'Collecting changed C# files…' });

      const baseRef = await resolveBaseRef(repoRoot, configuredBase);
      let files: ChangedFile[];
      try {
        files = await getChangedCSharpFiles({
          repoRoot,
          baseRef,
          stagedOnly: opts.stagedOnly,
          includeUntracked,
          onlyPath: opts.onlyPath
        });
      } catch (e: any) {
        vscode.window.showErrorMessage(`Failed to read git changes: ${e?.message ?? e}`);
        return;
      }

      if (!files.length) {
        vscode.window.showInformationMessage('No changed C# files to review.');
        return;
      }

      output.appendLine(`\n=== Review @ ${new Date().toLocaleString()} ===`);
      output.appendLine(`Model: ${model.family} (${model.id}) · base: ${baseRef} · files: ${files.length}`);

      const reviews: FileReview[] = [];
      let done = 0;
      for (const file of files) {
        if (token.isCancellationRequested) break;
        progress.report({ message: `Reviewing ${file.relPath} (${++done}/${files.length})`, increment: 100 / files.length });

        if (Buffer.byteLength(file.diff, 'utf8') > maxDiffBytes) {
          output.appendLine(`SKIP ${file.relPath}: diff too large (${Buffer.byteLength(file.diff)} bytes).`);
          continue;
        }
        const review = await reviewFile(model, file, customGuidelines, token);
        reviews.push(review);

        if (review.error) {
          output.appendLine(`ERROR ${file.relPath}: ${review.error}`);
        } else {
          output.appendLine(`\n${file.relPath} — ${review.summary}`);
          for (const f of review.findings) {
            output.appendLine(`  L${f.line} [${f.severity}/${f.category}] ${f.title}`);
          }
          if (!review.findings.length) output.appendLine('  ✓ No issues found.');
        }
      }

      diagnostics.render(reviews, threshold);

      const total = reviews.reduce((n, r) => n + r.findings.length, 0);
      const errors = reviews.reduce((n, r) => n + r.findings.filter(f => f.severity === 'error').length, 0);
      if (total === 0) {
        vscode.window.showInformationMessage('C# review complete — no issues found. 🎉');
      } else {
        const choice = await vscode.window.showInformationMessage(
          `C# review complete: ${total} comment(s), ${errors} error-level. See Problems panel.`,
          'Open Problems', 'Show Log'
        );
        if (choice === 'Open Problems') vscode.commands.executeCommand('workbench.actions.view.problems');
        if (choice === 'Show Log') output.show();
      }
    }
  );
}
