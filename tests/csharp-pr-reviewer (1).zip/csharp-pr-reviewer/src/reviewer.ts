import * as vscode from 'vscode';
import { ChangedFile } from './git';
import { buildSystemPrompt, buildUserPrompt } from './prompts';

export interface Finding {
  line: number;
  endLine?: number;
  severity: 'error' | 'warning' | 'info';
  category: string;
  title: string;
  detail: string;
  suggestion?: string;
}

export interface FileReview {
  file: ChangedFile;
  summary: string;
  findings: Finding[];
  error?: string;
}

/** Select a Copilot chat model, preferring the configured family. */
export async function selectModel(preferred: string): Promise<vscode.LanguageModelChat | undefined> {
  // Copilot models are exposed through the 'copilot' vendor.
  let models = await vscode.lm.selectChatModels({ vendor: 'copilot' });
  if (!models.length) {
    // Fall back to any available provider.
    models = await vscode.lm.selectChatModels();
  }
  if (!models.length) return undefined;

  const wanted = preferred.toLowerCase();
  const exact = models.find(m => m.family.toLowerCase() === wanted || m.id.toLowerCase() === wanted);
  if (exact) return exact;
  const partial = models.find(m => m.family.toLowerCase().includes(wanted));
  return partial ?? models[0];
}

/** Extract the first balanced JSON object from a model response. */
function extractJson(text: string): string | undefined {
  // Strip code fences if present.
  const fenced = /```(?:json)?\s*([\s\S]*?)```/i.exec(text);
  const candidate = fenced ? fenced[1] : text;
  const start = candidate.indexOf('{');
  if (start < 0) return undefined;
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < candidate.length; i++) {
    const c = candidate[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === '"') inStr = false;
    } else {
      if (c === '"') inStr = true;
      else if (c === '{') depth++;
      else if (c === '}') {
        depth--;
        if (depth === 0) return candidate.slice(start, i + 1);
      }
    }
  }
  return undefined;
}

function coerceFindings(raw: any, file: ChangedFile): Finding[] {
  if (!raw || !Array.isArray(raw.findings)) return [];
  const maxLine = file.content.split('\n').length;
  const out: Finding[] = [];
  for (const f of raw.findings) {
    const line = Number(f.line);
    if (!Number.isFinite(line) || line < 1 || line > maxLine) continue;
    const sev = ['error', 'warning', 'info'].includes(f.severity) ? f.severity : 'warning';
    out.push({
      line,
      endLine: Number.isFinite(Number(f.endLine)) ? Number(f.endLine) : undefined,
      severity: sev,
      category: String(f.category ?? 'design'),
      title: String(f.title ?? 'Review comment').slice(0, 120),
      detail: String(f.detail ?? ''),
      suggestion: f.suggestion ? String(f.suggestion) : undefined
    });
  }
  return out;
}

/** Run the model review for one file. */
export async function reviewFile(
  model: vscode.LanguageModelChat,
  file: ChangedFile,
  customGuidelines: string,
  token: vscode.CancellationToken
): Promise<FileReview> {
  const messages = [
    vscode.LanguageModelChatMessage.User(buildSystemPrompt(customGuidelines)),
    vscode.LanguageModelChatMessage.User(buildUserPrompt(file))
  ];

  try {
    const response = await model.sendRequest(messages, {}, token);
    let text = '';
    for await (const chunk of response.text) {
      text += chunk;
    }
    const json = extractJson(text);
    if (!json) {
      return { file, summary: '', findings: [], error: 'Model returned no parseable JSON.' };
    }
    const parsed = JSON.parse(json);
    return {
      file,
      summary: String(parsed.summary ?? ''),
      findings: coerceFindings(parsed, file)
    };
  } catch (err: any) {
    if (err instanceof vscode.LanguageModelError) {
      return { file, summary: '', findings: [], error: `${err.code}: ${err.message}` };
    }
    return { file, summary: '', findings: [], error: err?.message ?? String(err) };
  }
}
