import * as vscode from 'vscode';
import { FileReview, Finding } from './reviewer';

const SEVERITY_ORDER: Record<string, number> = { info: 0, warning: 1, error: 2 };

function toVsSeverity(sev: string): vscode.DiagnosticSeverity {
  switch (sev) {
    case 'error': return vscode.DiagnosticSeverity.Error;
    case 'info': return vscode.DiagnosticSeverity.Information;
    default: return vscode.DiagnosticSeverity.Warning;
  }
}

export class ReviewDiagnostics {
  private readonly collection: vscode.DiagnosticCollection;
  /** Keep findings keyed by uri string for the quick-fix provider. */
  public readonly findingsByUri = new Map<string, Finding[]>();

  constructor() {
    this.collection = vscode.languages.createDiagnosticCollection('csharp-pr-reviewer');
  }

  clear() {
    this.collection.clear();
    this.findingsByUri.clear();
  }

  dispose() {
    this.collection.dispose();
  }

  render(reviews: FileReview[], threshold: string) {
    this.clear();
    const min = SEVERITY_ORDER[threshold] ?? 0;

    for (const review of reviews) {
      const uri = vscode.Uri.file(review.file.absPath);
      const diags: vscode.Diagnostic[] = [];
      const kept: Finding[] = [];

      for (const f of review.findings) {
        if ((SEVERITY_ORDER[f.severity] ?? 1) < min) continue;
        const startLine = Math.max(0, f.line - 1);
        const endLine = Math.max(startLine, (f.endLine ?? f.line) - 1);
        const range = new vscode.Range(startLine, 0, endLine, Number.MAX_SAFE_INTEGER);

        const message = `[${f.category}] ${f.title}\n${f.detail}${f.suggestion ? `\n\n💡 Fix: ${f.suggestion}` : ''}`;
        const diag = new vscode.Diagnostic(range, message, toVsSeverity(f.severity));
        diag.source = 'C# Pre-PR Reviewer';
        diag.code = f.category;
        diags.push(diag);
        kept.push(f);
      }

      if (diags.length) {
        this.collection.set(uri, diags);
        this.findingsByUri.set(uri.toString(), kept);
      }
    }
  }
}

/** Provides "Copy suggestion" quick fixes for our diagnostics. */
export class SuggestionActionProvider implements vscode.CodeActionProvider {
  constructor(private readonly store: ReviewDiagnostics) {}

  provideCodeActions(
    document: vscode.TextDocument,
    range: vscode.Range,
    context: vscode.CodeActionContext
  ): vscode.CodeAction[] {
    const findings = this.store.findingsByUri.get(document.uri.toString()) ?? [];
    const actions: vscode.CodeAction[] = [];

    for (const diag of context.diagnostics) {
      if (diag.source !== 'C# Pre-PR Reviewer') continue;
      const line = diag.range.start.line + 1;
      const match = findings.find(f => f.line === line && diag.message.includes(f.title));
      if (!match?.suggestion) continue;

      const action = new vscode.CodeAction(
        `💡 Copy suggested fix: ${match.title}`,
        vscode.CodeActionKind.QuickFix
      );
      action.diagnostics = [diag];
      action.command = {
        command: 'csharpReviewer.copySuggestion',
        title: 'Copy suggestion',
        arguments: [match.suggestion]
      };
      actions.push(action);
    }
    return actions;
  }
}
